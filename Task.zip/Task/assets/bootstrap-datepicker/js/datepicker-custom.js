// =========showing today's date always

// $(function () {
//   $("#datepicker").datepicker({ 
//         autoclose: true, 
//         todayHighlight: true
//   }).datepicker('update', new Date());
// });
/*

Author: MH RONY
CompunyName: Code Camp BD
Facebook Profile: https://www.facebook.com/mh.rony.dhanvi
GitHub Link: https://github.com/dev-mhrony
Youtube Channel: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw
Personal Website: https://developerrony.com
Video Link: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw


*/

// =========empty input field
$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker2").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker3").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});

$(function () {
  $("#datepicker4").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  });
});